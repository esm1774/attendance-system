-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 22 أكتوبر 2025 الساعة 11:59
-- إصدار الخادم: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance`
--

-- --------------------------------------------------------

--
-- بنية الجدول `attendances`
--

CREATE TABLE `attendances` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `subject_id` bigint(20) UNSIGNED NOT NULL,
  `class_id` bigint(20) UNSIGNED NOT NULL,
  `attendance_date` date NOT NULL,
  `status` enum('present','absent','late','excused') NOT NULL DEFAULT 'present',
  `arrival_time` time DEFAULT NULL,
  `departure_time` time DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `recorded_by` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `classes`
--

CREATE TABLE `classes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `grade_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `name_ar` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT 30,
  `teacher_id` bigint(20) UNSIGNED DEFAULT NULL,
  `description` text DEFAULT NULL,
  `room_number` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `class_subjects`
--

CREATE TABLE `class_subjects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `school_class_id` bigint(20) UNSIGNED NOT NULL,
  `subject_id` bigint(20) UNSIGNED NOT NULL,
  `weekly_hours` int(11) NOT NULL DEFAULT 5,
  `academic_year` int(11) NOT NULL DEFAULT 2024,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `excuses`
--

CREATE TABLE `excuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `attendance_id` bigint(20) UNSIGNED DEFAULT NULL,
  `absence_date` date NOT NULL,
  `type` enum('sick','personal','family','other') NOT NULL DEFAULT 'sick',
  `reason` text NOT NULL,
  `notes` text DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `approved_by` bigint(20) UNSIGNED DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `grades`
--

CREATE TABLE `grades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `stage_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `name_ar` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  `level` int(11) NOT NULL DEFAULT 1,
  `min_grade` decimal(5,2) NOT NULL DEFAULT 0.00,
  `max_grade` decimal(5,2) NOT NULL DEFAULT 100.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `grades`
--

INSERT INTO `grades` (`id`, `stage_id`, `name`, `name_ar`, `code`, `description`, `order`, `level`, `min_grade`, `max_grade`, `is_active`, `created_at`, `updated_at`) VALUES
(10, 3, 'Grade 10', 'الصف الأول ثانوي', 'G10', 'الصف الأول الثانوي', 1, 10, 50.00, 100.00, 1, '2025-10-16 11:04:42', '2025-10-16 11:04:42'),
(11, 3, 'Grade 11', 'الصف الثاني ثانوي', 'G11', 'الصف الثاني الثانوي', 2, 11, 50.00, 100.00, 1, '2025-10-16 11:04:42', '2025-10-16 11:04:42'),
(12, 3, 'Grade 12', 'الصف الثالث ثانوي', 'G12', 'الصف الثالث الثانوي', 3, 12, 50.00, 100.00, 1, '2025-10-16 11:04:42', '2025-10-16 11:04:42');

-- --------------------------------------------------------

--
-- بنية الجدول `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_10_16_055757_0001_create_roles_table', 1),
(5, '2025_10_16_055757_0002_create_permissions_table', 1),
(6, '2025_10_16_055758_0003_create_role_permissions_table', 1),
(7, '2025_10_16_055758_0004_create_user_permissions_table', 1),
(8, '2025_10_16_062001_add_role_id_to_users_table', 1),
(9, '2025_10_16_065012_add_role_id_to_users_table', 1),
(10, '2025_10_16_080602_create_subjects_table', 1),
(11, '2025_10_16_092224_create_schools_table', 1),
(12, '2025_10_16_095626_create_stages_table', 1),
(13, '2025_10_16_135049_create_grades_table', 2),
(14, '2025_10_16_153553_create_classes_table', 3),
(15, '2025_10_16_164707_create_school_classes_table', 4),
(16, '2025_10_16_170702_add_teacher_fields_to_users_table', 5),
(17, '2025_10_16_175641_create_teacher_subjects_table', 6),
(18, '2025_10_16_182936_create_students_table', 7),
(19, '2025_10_16_195018_create_class_subjects_table', 8),
(20, '2025_10_16_195108_create_subject_grades_table', 8),
(23, '2025_10_16_195206_create_attendances_table', 9),
(24, '2025_10_16_195321_create_excuses_table', 9),
(26, '2025_10_18_050923_update_students_table', 10),
(27, '2025_10_16_195424_create_student_grades_table', 11),
(28, '2025_10_16_200312_create_student_grades_table_fixed', 11),
(29, '2025_10_20_061843_update_students_table_simplified', 12),
(30, '2025_10_20_061913_update_students_table_simplified', 12),
(31, '2025_10_20_063254_add_deleted_at_to_students_table', 13),
(32, '2025_10_21_080352_add_student_id_to_students_table', 14),
(40, '2025_10_22_091423_drop_teacher_subjects_table', 15);

-- --------------------------------------------------------

--
-- بنية الجدول `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `name_ar` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `name_ar`, `group`, `description`, `created_at`, `updated_at`) VALUES
(1, 'view_dashboard', 'عرض لوحة التحكم', 'dashboard', 'القدرة على عرض لوحة التحكم الرئيسية', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(2, 'view_statistics', 'عرض الإحصائيات', 'dashboard', 'القدرة على عرض الإحصائيات والتقارير', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(3, 'manage_users', 'إدارة المستخدمين', 'users', 'القدرة على إضافة وتعديل وحذف المستخدمين', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(4, 'view_users', 'عرض المستخدمين', 'users', 'القدرة على عرض قائمة المستخدمين', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(5, 'create_users', 'إنشاء مستخدمين', 'users', 'القدرة على إنشاء مستخدمين جدد', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(6, 'edit_users', 'تعديل المستخدمين', 'users', 'القدرة على تعديل بيانات المستخدمين', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(7, 'delete_users', 'حذف المستخدمين', 'users', 'القدرة على حذف المستخدمين', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(8, 'manage_students', 'إدارة الطلاب', 'students', 'القدرة على إدارة الطلاب', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(9, 'view_students', 'عرض الطلاب', 'students', 'القدرة على عرض قائمة الطلاب', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(10, 'create_students', 'إضافة طلاب', 'students', 'القدرة على إضافة طلاب جدد', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(11, 'edit_students', 'تعديل الطلاب', 'students', 'القدرة على تعديل بيانات الطلاب', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(12, 'delete_students', 'حذف الطلاب', 'students', 'القدرة على حذف الطلاب', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(13, 'manage_attendance', 'إدارة الحضور', 'attendance', 'القدرة على إدارة الحضور والغياب', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(14, 'take_attendance', 'تسجيل الحضور', 'attendance', 'القدرة على تسجيل الحضور والغياب', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(15, 'view_attendance', 'عرض الحضور', 'attendance', 'القدرة على عرض سجلات الحضور', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(16, 'manage_excuses', 'إدارة الأعذار', 'attendance', 'القدرة على إدارة أعذار الغياب', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(17, 'view_reports', 'عرض التقارير', 'reports', 'القدرة على عرض التقارير', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(18, 'export_reports', 'تصدير التقارير', 'reports', 'القدرة على تصدير التقارير', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(19, 'manage_settings', 'إدارة الإعدادات', 'settings', 'القدرة على تعديل إعدادات النظام', '2025-10-16 11:03:09', '2025-10-16 11:03:09'),
(20, 'manage_roles', 'إدارة الأدوار', 'settings', 'القدرة على إدارة الأدوار والصلاحيات', '2025-10-16 11:03:09', '2025-10-16 11:03:09');

-- --------------------------------------------------------

--
-- بنية الجدول `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `name_ar` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `roles`
--

INSERT INTO `roles` (`id`, `name`, `name_ar`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'مدير النظام', 'مدير النظام مع صلاحيات كاملة', 1, '2025-10-16 11:02:45', '2025-10-16 11:02:45'),
(2, 'vice_principal', 'الوكيل', 'وكيل المدرسة مع صلاحيات إدارية', 1, '2025-10-16 11:02:45', '2025-10-16 11:02:45'),
(3, 'supervisor', 'المراقب', 'مراقب مع صلاحيات متابعة الحضور والغياب', 1, '2025-10-16 11:02:45', '2025-10-16 11:02:45'),
(4, 'teacher', 'المعلم', 'معلم مع صلاحيات محدودة', 1, '2025-10-16 11:02:45', '2025-10-19 06:52:59');

-- --------------------------------------------------------

--
-- بنية الجدول `role_permissions`
--

CREATE TABLE `role_permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `role_permissions`
--

INSERT INTO `role_permissions` (`id`, `role_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(2, 1, 2, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(3, 1, 3, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(4, 1, 4, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(5, 1, 5, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(6, 1, 6, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(7, 1, 7, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(8, 1, 8, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(9, 1, 9, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(10, 1, 10, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(11, 1, 11, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(12, 1, 12, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(13, 1, 13, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(14, 1, 14, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(15, 1, 15, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(16, 1, 16, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(17, 1, 17, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(18, 1, 18, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(19, 1, 19, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(20, 1, 20, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(21, 2, 1, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(22, 2, 2, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(23, 2, 3, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(24, 2, 4, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(25, 2, 5, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(26, 2, 6, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(27, 2, 8, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(28, 2, 9, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(29, 2, 10, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(30, 2, 11, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(31, 2, 13, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(32, 2, 14, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(33, 2, 15, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(34, 2, 16, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(35, 2, 17, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(36, 2, 18, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(37, 3, 1, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(38, 3, 2, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(39, 3, 8, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(40, 3, 9, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(41, 3, 11, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(42, 3, 13, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(43, 3, 14, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(44, 3, 15, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(45, 3, 16, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(46, 3, 17, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(47, 3, 18, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(48, 4, 1, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(49, 4, 9, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(50, 4, 14, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(51, 4, 15, '2025-10-16 11:03:24', '2025-10-16 11:03:24'),
(52, 4, 16, '2025-10-16 11:03:24', '2025-10-16 11:03:24');

-- --------------------------------------------------------

--
-- بنية الجدول `schools`
--

CREATE TABLE `schools` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `name_ar` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `principal_name` varchar(255) DEFAULT NULL,
  `principal_name_ar` varchar(255) DEFAULT NULL,
  `established_year` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `schools`
--

INSERT INTO `schools` (`id`, `name`, `name_ar`, `code`, `address`, `phone`, `email`, `principal_name`, `principal_name_ar`, `established_year`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 'النخبة الأهلية', 'النخبة الأهلية', 'SCH-001', NULL, NULL, NULL, 'سعد', 'سعد', 2011, NULL, 1, '2025-10-21 06:27:37', '2025-10-22 05:26:10');

-- --------------------------------------------------------

--
-- بنية الجدول `school_classes`
--

CREATE TABLE `school_classes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `grade_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `name_ar` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT 30,
  `teacher_id` bigint(20) UNSIGNED DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `school_classes`
--

INSERT INTO `school_classes` (`id`, `grade_id`, `name`, `name_ar`, `code`, `capacity`, `teacher_id`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
(6, 10, '١ ثانوي ١', '١ ثانوي ١', 'CLS-011', 30, NULL, NULL, 1, '2025-10-21 04:04:36', '2025-10-21 04:29:08'),
(7, 10, '١ ثانوي ٢', '١ ثانوي ٢', 'CLS-012', 30, NULL, NULL, 1, '2025-10-21 04:18:18', '2025-10-21 04:28:46'),
(8, 10, '١ ثانوي ٣', '١ ثانوي ٣', 'CLS-013', 30, NULL, NULL, 1, '2025-10-21 04:19:16', '2025-10-21 04:29:56'),
(9, 11, '٢ ثانوي ١', '٢ ثانوي ١', 'CLS-021', 30, NULL, NULL, 1, '2025-10-21 04:20:41', '2025-10-22 05:26:43'),
(10, 11, '٢ ثانوي ٢', '٢ ثانوي ٢', 'CLS-022', 30, NULL, NULL, 1, '2025-10-21 04:21:48', '2025-10-21 04:21:48'),
(11, 11, '٢ ثانوي ٣', '٢ ثانوي ٣', 'CLS-023', 30, NULL, NULL, 1, '2025-10-21 04:23:35', '2025-10-21 04:23:35'),
(12, 12, '٣ ثانوي ١', '٣ ثانوي ١', 'CLS-031', 30, NULL, NULL, 1, '2025-10-21 04:24:42', '2025-10-21 04:24:42'),
(13, 11, '٣ ثانوي ٢', '٣ ثانوي ٢', 'CLS-032', 30, NULL, NULL, 1, '2025-10-21 04:25:39', '2025-10-21 04:25:39'),
(14, 12, '٣ ثانوي ٣', '٣ ثانوي ٣', 'CLS-033', 30, NULL, NULL, 1, '2025-10-21 04:26:55', '2025-10-21 04:26:55');

-- --------------------------------------------------------

--
-- بنية الجدول `stages`
--

CREATE TABLE `stages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `school_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `name_ar` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  `min_age` int(11) DEFAULT NULL,
  `max_age` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `stages`
--

INSERT INTO `stages` (`id`, `school_id`, `name`, `name_ar`, `code`, `description`, `order`, `min_age`, `max_age`, `is_active`, `created_at`, `updated_at`) VALUES
(3, 2, 'المرحلة الثانوية', 'المرحلة الثانوية', 'SEC', 'المرحلة الثانوية من الصف الأول إلى الثالث', 3, 15, 18, 1, '2025-10-16 11:04:32', '2025-10-21 06:31:49');

-- --------------------------------------------------------

--
-- بنية الجدول `students`
--

CREATE TABLE `students` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_id` varchar(255) DEFAULT NULL,
  `class_id` bigint(20) UNSIGNED NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `national_id` varchar(20) NOT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` enum('male','female') DEFAULT NULL,
  `nationality` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `guardian_name` varchar(255) DEFAULT NULL,
  `guardian_relation` varchar(255) DEFAULT NULL,
  `guardian_phone` varchar(255) DEFAULT NULL,
  `guardian_email` varchar(255) DEFAULT NULL,
  `enrollment_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `status` enum('active','transferred','graduated','withdrawn') NOT NULL DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `students`
--

INSERT INTO `students` (`id`, `student_id`, `class_id`, `full_name`, `national_id`, `birth_date`, `gender`, `nationality`, `phone`, `email`, `guardian_name`, `guardian_relation`, `guardian_phone`, `guardian_email`, `enrollment_date`, `is_active`, `status`, `notes`, `created_at`, `updated_at`, `deleted_at`) VALUES
(61, NULL, 6, 'إبراهيم عبدالعزيز إبراهيم الرويس', '101111111', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(62, NULL, 6, 'تركي ماجد معتق المطيري', '101111112', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(63, NULL, 6, 'خالد حمود حشر القحطاني', '101111113', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(64, NULL, 6, 'زياد أحمد علي الشمراني', '101111114', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(65, NULL, 6, 'سلمان حسن عبدالله البيشي', '101111115', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(66, NULL, 6, 'صقر قبلان صقر العتيبي', '101111116', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(67, NULL, 6, 'عارف أحمد محمد الزجاء', '101111117', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(68, NULL, 6, 'عبدالرحمن سعيد عبدالرحمن العتيبي', '101111118', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(69, NULL, 6, 'عبدالعزيز محمد عبدالعزيز التميمي', '101111119', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(70, NULL, 6, 'عبدالله سعد عبدالله القرني', '101111120', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(71, NULL, 6, 'عبدالله دواس مشلح الدوسري', '101111121', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(72, NULL, 6, 'فهد عبدالحميد فهد بن طلحه', '101111122', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(73, NULL, 6, 'مازن فهد سلمان المطيري', '101111123', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(74, NULL, 6, 'مسفر شبيب مقعد الدوسري', '101111124', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(75, NULL, 6, 'ناجي برغش ناجي الدوسري', '101111125', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(76, NULL, 6, 'نايف حمد محمد العمر', '101111126', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(77, NULL, 6, 'الوليد خالد حرشان الدوسري', '101111127', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(78, NULL, 6, 'يزن حاكم إبراهيم الدوسري', '101111128', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(79, NULL, 7, 'أمير حسين أحمد محنشي', '101111129', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(80, NULL, 7, 'راكان عبدالله عبدالعزيز العبيداء', '101111130', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(81, NULL, 7, 'ريان عبدالعزيز سالم المبارك', '101111131', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(82, NULL, 7, 'سالم حزيم سالم الدوسري', '101111132', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(83, NULL, 7, 'سالم خالد سالم المبارك', '101111133', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(84, NULL, 7, 'سيف أحمد مصلح البلوي', '101111134', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(85, NULL, 7, 'عبدالإله إبراهيم علي العبيداء', '101111135', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(86, NULL, 7, 'عبدالرحمن عبدالله نفل الدوسري', '101111136', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(87, NULL, 7, 'عبدالرحمن يحيى علي بجوي', '101111137', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(88, NULL, 7, 'عبدالله عبدالرحمن عويد الحربي', '101111138', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(89, NULL, 7, 'عبدالله عبدالرحمن ناصر البعيجان', '101111139', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(90, NULL, 7, 'عبدالمجيد حسن محمد عسيري', '101111140', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(91, NULL, 7, 'فايز أحمد فايز الحربي', '101111141', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(92, NULL, 7, 'فهد نواف فهد القباني السهلي', '101111142', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(93, NULL, 7, 'محمد بدر محمد الدوسري', '101111143', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(94, NULL, 7, 'محمد خالد محمد الأحمري', '101111144', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(95, NULL, 7, 'محمد ناصر معجب الدوسري', '101111145', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(96, NULL, 7, 'ناصر عبدالإله ناصر المعيبد', '101111146', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(97, NULL, 7, 'وافي خالد محمد البقمي', '101111147', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL),
(98, NULL, 7, 'وسام أحمد فالح الرشيدي', '101111148', NULL, NULL, 'سعودي', NULL, NULL, NULL, 'الأب', NULL, NULL, '2025-10-21', 1, 'active', NULL, '2025-10-21 06:25:38', '2025-10-21 06:25:38', NULL);

-- --------------------------------------------------------

--
-- بنية الجدول `student_grades`
--

CREATE TABLE `student_grades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `subject_id` bigint(20) UNSIGNED NOT NULL,
  `class_id` bigint(20) UNSIGNED NOT NULL,
  `subject_grade_id` bigint(20) UNSIGNED NOT NULL,
  `grade` decimal(5,2) NOT NULL DEFAULT 0.00,
  `academic_year` int(11) NOT NULL,
  `semester` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `graded_by` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `student_grades_fixed`
--

CREATE TABLE `student_grades_fixed` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `subject_id` bigint(20) UNSIGNED NOT NULL,
  `class_id` bigint(20) UNSIGNED NOT NULL,
  `subject_grade_id` bigint(20) UNSIGNED NOT NULL,
  `grade` decimal(5,2) NOT NULL DEFAULT 0.00,
  `academic_year` int(11) NOT NULL,
  `semester` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `graded_by` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `subjects`
--

CREATE TABLE `subjects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `name_ar` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('mandatory','elective') NOT NULL DEFAULT 'mandatory',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `name_ar`, `code`, `description`, `type`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Mathematics', 'الرياضيات', 'MATH-001', 'مادة الرياضيات تشمل الجبر والهندسة والإحصاء', 'mandatory', 1, '2025-10-16 11:03:40', '2025-10-16 11:03:40'),
(2, 'Arabic Language', 'اللغة العربية', 'ARAB-001', 'مادة اللغة العربية تشمل النحو والأدب والبلاغة', 'mandatory', 1, '2025-10-16 11:03:40', '2025-10-16 11:03:40'),
(3, 'Science', 'العلوم', 'SCI-001', 'مادة العلوم تشمل الفيزياء والكيمياء والأحياء', 'mandatory', 1, '2025-10-16 11:03:40', '2025-10-16 11:03:40'),
(4, 'English Language', 'اللغة الإنجليزية', 'ENG-001', 'مادة اللغة الإنجليزية تشمل القراءة والمحادثة والقواعد', 'mandatory', 1, '2025-10-16 11:03:40', '2025-10-16 11:03:40'),
(5, 'Islamic Education', 'التربية الإسلامية', 'ISL-001', 'مادة التربية الإسلامية تشمل القرآن الكريم والحديث والفقه', 'mandatory', 1, '2025-10-16 11:03:40', '2025-10-16 11:03:40'),
(6, 'Social Studies', 'الدراسات الاجتماعية', 'SOC-001', 'مادة الدراسات الاجتماعية تشمل التاريخ والجغرافيا', 'mandatory', 1, '2025-10-16 11:03:40', '2025-10-16 11:03:40'),
(7, 'Computer Science', 'الحاسب الآلي', 'COMP-001', 'مادة الحاسب الآلي تشمل البرمجة والمهارات الرقمية', 'elective', 1, '2025-10-16 11:03:40', '2025-10-16 11:03:40'),
(8, 'Art Education', 'التربية الفنية', 'ART-001', 'مادة التربية الفنية تشمل الرسم والأشغال اليدوية', 'elective', 1, '2025-10-16 11:03:40', '2025-10-16 11:03:40'),
(9, 'Badnia', 'التربية البدنية', 'BDN-001', 'التربية البدنية', 'elective', 1, '2025-10-20 00:11:32', '2025-10-20 00:11:32'),
(10, 'All-School', 'غياب المدرسة', 'SCH-000', 'جميع المدرسة وتم وضعها عندما يأخذ الوكيل أو الإدارة الغياب', 'elective', 1, '2025-10-21 04:40:43', '2025-10-21 04:40:43');

-- --------------------------------------------------------

--
-- بنية الجدول `subject_grades`
--

CREATE TABLE `subject_grades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subject_id` bigint(20) UNSIGNED NOT NULL,
  `grade_type` varchar(255) NOT NULL,
  `grade_type_ar` varchar(255) NOT NULL,
  `min_grade` decimal(5,2) NOT NULL DEFAULT 0.00,
  `max_grade` decimal(5,2) NOT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role_id` bigint(20) UNSIGNED DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `teacher_id` varchar(255) DEFAULT NULL,
  `specialization` varchar(255) DEFAULT NULL,
  `qualification` varchar(255) DEFAULT NULL,
  `years_of_experience` int(11) DEFAULT 0,
  `hire_date` date DEFAULT NULL,
  `employment_type` enum('full_time','part_time','contract') DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `role_id`, `phone`, `address`, `is_active`, `teacher_id`, `specialization`, `qualification`, `years_of_experience`, `hire_date`, `employment_type`, `salary`, `notes`) VALUES
(3, 'إسماعيل محمد', 'esm1977@gmail.com', NULL, '$2y$12$Q49TC8HN6grV5h.6VnNUIO.Mt3bS1Cav3mFo9TjtY0BkSx1A4sdEa', NULL, '2025-10-16 15:24:00', '2025-10-18 06:33:04', 1, NULL, NULL, 1, '212', 'تربية رياضية', 'بكالوريوس', 0, '2017-12-30', 'full_time', NULL, NULL);

-- --------------------------------------------------------

--
-- بنية الجدول `user_permissions`
--

CREATE TABLE `user_permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `is_granted` tinyint(1) NOT NULL DEFAULT 1,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `user_permissions`
--

INSERT INTO `user_permissions` (`id`, `user_id`, `permission_id`, `is_granted`, `expires_at`, `created_at`, `updated_at`) VALUES
(26, 3, 1, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(27, 3, 2, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(28, 3, 3, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(29, 3, 4, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(30, 3, 5, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(31, 3, 6, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(32, 3, 7, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(33, 3, 8, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(34, 3, 9, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(35, 3, 10, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(36, 3, 11, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(37, 3, 12, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(38, 3, 13, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(39, 3, 14, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(40, 3, 15, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(41, 3, 16, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(42, 3, 17, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(43, 3, 18, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(44, 3, 19, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03'),
(45, 3, 20, 1, NULL, '2025-10-18 07:05:03', '2025-10-18 07:05:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendances`
--
ALTER TABLE `attendances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `attendances_student_id_subject_id_attendance_date_unique` (`student_id`,`subject_id`,`attendance_date`),
  ADD KEY `attendances_subject_id_foreign` (`subject_id`),
  ADD KEY `attendances_recorded_by_foreign` (`recorded_by`),
  ADD KEY `attendances_student_id_index` (`student_id`),
  ADD KEY `attendances_attendance_date_index` (`attendance_date`),
  ADD KEY `attendances_status_index` (`status`),
  ADD KEY `attendances_student_id_attendance_date_index` (`student_id`,`attendance_date`),
  ADD KEY `attendances_class_id_attendance_date_index` (`class_id`,`attendance_date`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `classes_code_unique` (`code`),
  ADD KEY `classes_grade_id_index` (`grade_id`),
  ADD KEY `classes_teacher_id_index` (`teacher_id`),
  ADD KEY `classes_code_index` (`code`),
  ADD KEY `classes_is_active_index` (`is_active`),
  ADD KEY `classes_grade_id_is_active_index` (`grade_id`,`is_active`);

--
-- Indexes for table `class_subjects`
--
ALTER TABLE `class_subjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `class_subjects_school_class_id_subject_id_academic_year_unique` (`school_class_id`,`subject_id`,`academic_year`),
  ADD KEY `class_subjects_subject_id_foreign` (`subject_id`),
  ADD KEY `class_subjects_school_class_id_subject_id_index` (`school_class_id`,`subject_id`),
  ADD KEY `class_subjects_academic_year_index` (`academic_year`),
  ADD KEY `class_subjects_is_active_index` (`is_active`);

--
-- Indexes for table `excuses`
--
ALTER TABLE `excuses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `excuses_attendance_id_foreign` (`attendance_id`),
  ADD KEY `excuses_approved_by_foreign` (`approved_by`),
  ADD KEY `excuses_student_id_index` (`student_id`),
  ADD KEY `excuses_absence_date_index` (`absence_date`),
  ADD KEY `excuses_type_index` (`type`),
  ADD KEY `excuses_status_index` (`status`),
  ADD KEY `excuses_student_id_absence_date_index` (`student_id`,`absence_date`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `grades_stage_id_name_unique` (`stage_id`,`name`),
  ADD KEY `grades_stage_id_index` (`stage_id`),
  ADD KEY `grades_is_active_index` (`is_active`),
  ADD KEY `grades_stage_id_is_active_index` (`stage_id`,`is_active`),
  ADD KEY `grades_order_index` (`order`),
  ADD KEY `grades_level_index` (`level`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role_permissions_role_id_permission_id_unique` (`role_id`,`permission_id`),
  ADD KEY `role_permissions_permission_id_foreign` (`permission_id`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `schools_code_unique` (`code`),
  ADD KEY `schools_code_index` (`code`),
  ADD KEY `schools_is_active_index` (`is_active`),
  ADD KEY `schools_is_active_code_index` (`is_active`,`code`);

--
-- Indexes for table `school_classes`
--
ALTER TABLE `school_classes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `school_classes_grade_id_name_unique` (`grade_id`,`name`),
  ADD UNIQUE KEY `school_classes_code_unique` (`code`),
  ADD KEY `school_classes_grade_id_index` (`grade_id`),
  ADD KEY `school_classes_teacher_id_index` (`teacher_id`),
  ADD KEY `school_classes_is_active_index` (`is_active`),
  ADD KEY `school_classes_grade_id_is_active_index` (`grade_id`,`is_active`);

--
-- Indexes for table `stages`
--
ALTER TABLE `stages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stages_school_id_name_unique` (`school_id`,`name`),
  ADD KEY `stages_school_id_index` (`school_id`),
  ADD KEY `stages_is_active_index` (`is_active`),
  ADD KEY `stages_school_id_is_active_index` (`school_id`,`is_active`),
  ADD KEY `stages_order_index` (`order`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `students_national_id_unique` (`national_id`),
  ADD UNIQUE KEY `students_email_unique` (`email`),
  ADD UNIQUE KEY `students_student_id_unique` (`student_id`),
  ADD KEY `students_class_id_index` (`class_id`),
  ADD KEY `students_national_id_index` (`national_id`),
  ADD KEY `students_gender_index` (`gender`),
  ADD KEY `students_is_active_index` (`is_active`),
  ADD KEY `students_status_index` (`status`),
  ADD KEY `students_class_id_is_active_index` (`class_id`,`is_active`),
  ADD KEY `students_gender_is_active_index` (`gender`,`is_active`);

--
-- Indexes for table `student_grades`
--
ALTER TABLE `student_grades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_grades_unique` (`student_id`,`subject_id`,`subject_grade_id`,`academic_year`,`semester`),
  ADD KEY `student_grades_class_id_foreign` (`class_id`),
  ADD KEY `student_grades_subject_grade_id_foreign` (`subject_grade_id`),
  ADD KEY `student_grades_graded_by_foreign` (`graded_by`),
  ADD KEY `student_grades_student_idx` (`student_id`),
  ADD KEY `student_grades_subject_idx` (`subject_id`),
  ADD KEY `student_grades_year_idx` (`academic_year`),
  ADD KEY `student_grades_semester_idx` (`semester`),
  ADD KEY `student_grades_main_idx` (`student_id`,`subject_id`,`academic_year`,`semester`);

--
-- Indexes for table `student_grades_fixed`
--
ALTER TABLE `student_grades_fixed`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `std_grades_unique` (`student_id`,`subject_id`,`subject_grade_id`,`academic_year`,`semester`),
  ADD KEY `student_grades_fixed_class_id_foreign` (`class_id`),
  ADD KEY `student_grades_fixed_subject_grade_id_foreign` (`subject_grade_id`),
  ADD KEY `student_grades_fixed_graded_by_foreign` (`graded_by`),
  ADD KEY `std_grades_student_idx` (`student_id`),
  ADD KEY `std_grades_subject_idx` (`subject_id`),
  ADD KEY `std_grades_year_idx` (`academic_year`),
  ADD KEY `std_grades_semester_idx` (`semester`),
  ADD KEY `std_grades_main_idx` (`student_id`,`subject_id`,`academic_year`,`semester`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subjects_code_unique` (`code`),
  ADD KEY `subjects_code_index` (`code`),
  ADD KEY `subjects_type_index` (`type`),
  ADD KEY `subjects_is_active_index` (`is_active`),
  ADD KEY `subjects_is_active_type_index` (`is_active`,`type`);

--
-- Indexes for table `subject_grades`
--
ALTER TABLE `subject_grades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subject_grades_subject_id_grade_type_unique` (`subject_id`,`grade_type`),
  ADD KEY `subject_grades_subject_id_index` (`subject_id`),
  ADD KEY `subject_grades_is_active_index` (`is_active`),
  ADD KEY `subject_grades_subject_id_is_active_index` (`subject_id`,`is_active`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_teacher_id_unique` (`teacher_id`),
  ADD KEY `users_role_id_index` (`role_id`),
  ADD KEY `users_is_active_index` (`is_active`),
  ADD KEY `users_teacher_id_index` (`teacher_id`),
  ADD KEY `users_specialization_index` (`specialization`),
  ADD KEY `users_employment_type_index` (`employment_type`);

--
-- Indexes for table `user_permissions`
--
ALTER TABLE `user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_permissions_user_id_permission_id_unique` (`user_id`,`permission_id`),
  ADD KEY `user_permissions_permission_id_foreign` (`permission_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendances`
--
ALTER TABLE `attendances`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `class_subjects`
--
ALTER TABLE `class_subjects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `excuses`
--
ALTER TABLE `excuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `role_permissions`
--
ALTER TABLE `role_permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `school_classes`
--
ALTER TABLE `school_classes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `stages`
--
ALTER TABLE `stages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `student_grades`
--
ALTER TABLE `student_grades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_grades_fixed`
--
ALTER TABLE `student_grades_fixed`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `subject_grades`
--
ALTER TABLE `subject_grades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user_permissions`
--
ALTER TABLE `user_permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- قيود الجداول المُلقاة.
--

--
-- قيود الجداول `attendances`
--
ALTER TABLE `attendances`
  ADD CONSTRAINT `attendances_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `school_classes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendances_recorded_by_foreign` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendances_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendances_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- قيود الجداول `classes`
--
ALTER TABLE `classes`
  ADD CONSTRAINT `classes_grade_id_foreign` FOREIGN KEY (`grade_id`) REFERENCES `grades` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `classes_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- قيود الجداول `class_subjects`
--
ALTER TABLE `class_subjects`
  ADD CONSTRAINT `class_subjects_school_class_id_foreign` FOREIGN KEY (`school_class_id`) REFERENCES `school_classes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `class_subjects_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- قيود الجداول `excuses`
--
ALTER TABLE `excuses`
  ADD CONSTRAINT `excuses_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `excuses_attendance_id_foreign` FOREIGN KEY (`attendance_id`) REFERENCES `attendances` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `excuses_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- قيود الجداول `grades`
--
ALTER TABLE `grades`
  ADD CONSTRAINT `grades_stage_id_foreign` FOREIGN KEY (`stage_id`) REFERENCES `stages` (`id`) ON DELETE CASCADE;

--
-- قيود الجداول `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD CONSTRAINT `role_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- قيود الجداول `school_classes`
--
ALTER TABLE `school_classes`
  ADD CONSTRAINT `school_classes_grade_id_foreign` FOREIGN KEY (`grade_id`) REFERENCES `grades` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `school_classes_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- قيود الجداول `stages`
--
ALTER TABLE `stages`
  ADD CONSTRAINT `stages_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE;

--
-- قيود الجداول `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `school_classes` (`id`) ON DELETE CASCADE;

--
-- قيود الجداول `student_grades`
--
ALTER TABLE `student_grades`
  ADD CONSTRAINT `student_grades_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `school_classes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_grades_graded_by_foreign` FOREIGN KEY (`graded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_grades_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_grades_subject_grade_id_foreign` FOREIGN KEY (`subject_grade_id`) REFERENCES `subject_grades` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_grades_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- قيود الجداول `student_grades_fixed`
--
ALTER TABLE `student_grades_fixed`
  ADD CONSTRAINT `student_grades_fixed_class_id_foreign` FOREIGN KEY (`class_id`) REFERENCES `school_classes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_grades_fixed_graded_by_foreign` FOREIGN KEY (`graded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_grades_fixed_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_grades_fixed_subject_grade_id_foreign` FOREIGN KEY (`subject_grade_id`) REFERENCES `subject_grades` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_grades_fixed_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- قيود الجداول `subject_grades`
--
ALTER TABLE `subject_grades`
  ADD CONSTRAINT `subject_grades_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- قيود الجداول `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL;

--
-- قيود الجداول `user_permissions`
--
ALTER TABLE `user_permissions`
  ADD CONSTRAINT `user_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_permissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
